@extends('master.principal')
@section('title','Descargo')
@section('contenido')
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                  {!! Form::model($descargos, ['route'=>['descargo.update', $descargos->id], 'method' => 'PUT', 'class'=>'form-horizontal form-label-left' ]) !!}

                      
                      <span class="section">Editar Descargo</i></span>

                      <div class="item form-group">
                        {!!Form::label('email', 'Tipo de Documento', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])!!}
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <select onchange="cambiar();" id='tipo_doc' name='tipo_doc' class='form-control unidad'>
                          <option value='1'>Proveido</option>
                          <option value='2'>Oficio</option>
                          <option value='3'>Oficio Multiple</option>
                          <option value='4'>Resollución de Decanato</option>
                          <option value='5'>Otro</option>
                        </select>
                        <a href="" id="verificar" TARGET="_new">Verificar N°</a>

                        </div>
                      </div>

                      <div class="item form-group">
                        {!!Form::label('labe2', 'Cardex',['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])!!}
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        {!! Form::text('cardex', null, ['required', 'class'=> 'form-control','id'=>'txt_cardex', 'placeholder'=>'N° Registro de de documeto']) !!}
                       
                        </div>
                      </div>

                      <div class="item form-group">
                        {!!Form::label('email', 'Receptor',['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])!!}
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        {!! Form::text('receptor', null, ['required', 'class'=> 'form-control', 'placeholder'=>'Persona o oficina a la que se envia el documento'] ) !!}
                        </div>
                      </div>
                      {!!Form::hidden('users_id', Auth::user()->id)!!}
                      {!!Form::hidden('users_ed', Auth::user()->id)!!}
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-7">
                          <input type="submit" class="btn btn-success" value="Guardar Cambios">
                          <br><br><br><br><br><br>
                      </div>
                      </div>
                    {!! Form::close() !!}
                    <br><br><br><br><br><br><br><br><br><br>
                  </div>
                </div>
              </div>
              <input type="hidden" name="_token" value="{{csrf_token()}}" id="token"> 
@endsection

@section('pie')
<script>
function cambiar(){
    //var route="http://localhost/enfermeria/public/getcardex";
    var route="/enfermeria/public/getcardex";
    var id=$('#tipo_doc').val();
    
      var data={
      'id':id

    };    

    var token=$("#token").val();
    $.ajax({
      headers:{'X-CSRF-TOKEN':token},
      url:route,
      data:data,
      type:'GET',

      success: function(result){

        $('#txt_cardex').val(result);
        $('#txt_cardex2').val(id);
         //console.log(result);                  
      } 
    });


    //Direccionar URL 
    var elemento = document.getElementById("verificar");
    var tipoDocumento;
switch (id){
 case "1": tipoDocumento = "Proveido"; break;
 case "2": tipoDocumento = "Oficio"; break;
 case "3": tipoDocumento = "Oficio Multiple"; break;
 case "4": tipoDocumento = "Resolución de Decanato"; break;
 default: tipoDocumento = "Otro"; break; 
}
  elemento.innerHTML="Verificar N°"+" "+ tipoDocumento;
  elemento.href="../cardex/"+id;

  } 



      $(document).ready(function() {
        
        $('#wizard').smartWizard();

        $('#wizard_verticle').smartWizard({
          transitionEffect: 'slide'
        });

        $('.buttonNext').addClass('btn btn-success');
        $('.buttonPrevious').addClass('btn btn-primary');
        $('.buttonFinish').addClass('btn btn-default');
      });
</script>
@endsection